package com.example.reginald_williams;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * InventoryAdapter binds inventory data to the RecyclerView grid display.
 * It depends on the standalone Item model instead of a nested Activity class,
 * making the adapter easier to reuse and test.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private final List<Item> itemList;
    private final OnItemInteractionListener interactionListener;

    /**
     * Interface to handle UI events within the data grid.
     */
    public interface OnItemInteractionListener {
        void onDeleteClick(int id);
        void onUpdateClick(Item item);
    }

    public InventoryAdapter(List<Item> itemList, OnItemInteractionListener listener) {
        this.itemList = itemList;
        this.interactionListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = itemList.get(position);

        holder.nameText.setText(item.getName());
        holder.qtyText.setText("Stock: " + item.getQuantity());

        holder.deleteBtn.setOnClickListener(v -> interactionListener.onDeleteClick(item.getId()));
        holder.itemView.setOnClickListener(v -> interactionListener.onUpdateClick(item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    /**
     * ViewHolder pattern for efficient UI element reuse.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView qtyText;
        final Button deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemName);
            qtyText = itemView.findViewById(R.id.itemQty);
            deleteBtn = itemView.findViewById(R.id.deleteButton);
        }
    }
}

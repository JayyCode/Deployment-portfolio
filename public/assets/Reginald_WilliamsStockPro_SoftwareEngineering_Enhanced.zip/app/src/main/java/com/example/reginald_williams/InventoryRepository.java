package com.example.reginald_williams;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryRepository provides a clean boundary between InventoryActivity and
 * DatabaseHelper. UI classes call repository methods instead of working with
 * Cursor objects or raw database operations directly.
 */
public class InventoryRepository {
    private final DatabaseHelper databaseHelper;

    public InventoryRepository(Context context) {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public long addItem(String name, int quantity) {
        return databaseHelper.addItem(name, quantity);
    }

    public void updateQuantity(int itemId, int quantity) {
        databaseHelper.updateItem(itemId, quantity);
    }

    public void deleteItem(int itemId) {
        databaseHelper.deleteItem(itemId);
    }

    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        Cursor cursor = databaseHelper.getAllItems();

        if (cursor == null) {
            return items;
        }

        try {
            if (cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(0);
                    String name = cursor.getString(1);
                    int quantity = cursor.getInt(2);
                    items.add(new Item(id, name, quantity));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        return items;
    }
}

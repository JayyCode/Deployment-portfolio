package com.example.reginald_williams;

/**
 * Item is the standalone inventory domain model used across the UI, adapter,
 * repository, and database layers.
 *
 * Moving this model out of InventoryActivity improves separation of concerns:
 * activities can focus on screen behavior while the model represents inventory
 * data consistently throughout the application.
 */
public class Item {
    private final int id;
    private final String name;
    private final int quantity;

    public Item(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}

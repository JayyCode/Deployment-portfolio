# CS 499 Software Design and Engineering Enhancement - StockPro

## Enhancement Focus
This enhancement addresses the software design and engineering category for the StockPro CS 360 artifact. The original application placed UI behavior, validation, database access, item modeling, and notification behavior directly inside Activity classes. The refined version separates those responsibilities into focused classes while preserving the original app functionality.

## Real Code Findings Addressed
- `LoginActivity.java` originally handled UI input, validation, account creation, login checks, Toast messages, and navigation in one Activity.
- `InventoryActivity.java` originally handled UI setup, direct database CRUD calls, Cursor-to-list conversion, input parsing, SMS notification behavior, and a nested `Item` model in one Activity.
- `InventoryAdapter.java` originally depended on `InventoryActivity.Item`, which tightly coupled the adapter to the Activity.
- `AndroidManifest.xml` originally exported `MainActivity`, even though `LoginActivity` is the launcher and `MainActivity` is not part of the StockPro inventory workflow.

## Refined Design Changes
- Added `Item.java` as a standalone domain model.
- Added `InputValidator.java` to centralize reusable validation and prevent invalid quantity crashes.
- Added `AuthRepository.java` to separate authentication persistence from `LoginActivity`.
- Added `InventoryRepository.java` to separate inventory persistence and Cursor handling from `InventoryActivity`.
- Added `LowInventoryNotifier.java` to separate SMS notification behavior from `InventoryActivity`.
- Refactored `LoginActivity.java` to call helper methods and repository methods instead of containing all login logic inline.
- Refactored `InventoryActivity.java` to delegate validation, persistence, and notification work to focused classes.
- Refactored `InventoryAdapter.java` to depend on the standalone `Item` model instead of a nested Activity class.
- Updated `AndroidManifest.xml` so `MainActivity` is no longer exported and the unused `tools` namespace was removed.

## Course Outcome Alignment
This enhancement demonstrates cleaner architecture, separation of concerns, reusable validation, reduced coupling, safer manifest exposure, and more maintainable Android design. It supports professional software engineering practice because the code is easier to read, test, extend, and explain during the ePortfolio code review.

# CS 499 Milestone Four - Database Enhancement Summary

Artifact: StockPro mobile inventory application  
Course source: CS 360 Mobile Architecture and Programming  
Enhancement category: Databases

## Enhancement Scope

This database enhancement builds on the previous software engineering and algorithms/data structures enhancements. The focus is the SQLite data layer, credential storage, schema migration behavior, and database query support.

## Implemented Database Improvements

1. Expanded the inventory table from the original `id`, `name`, and `quantity` fields to a richer schema that includes `sku`, `category`, `reorder_threshold`, `updated_at`, and `owner_user_id`.
2. Increased the database version to 3 and replaced destructive upgrade behavior with migration logic that adds missing columns while preserving existing user and item records.
3. Added database indexes for item name, SKU, category, and low-stock query support.
4. Replaced `SELECT *` retrieval with explicit projection-based queries.
5. Added focused query methods for searching inventory records, retrieving low-stock items, sorting by quantity, and sorting by reorder priority.
6. Added `PasswordHasher` so new user passwords are stored as PBKDF2 hashes instead of plain text.
7. Added legacy-password migration logic so an older plain-text password can be upgraded to a hash after a successful login.
8. Updated `InventoryRepository`, `Item`, `InventoryAlgorithmEngine`, and `InventoryAdapter` so the enhanced database fields are usable across the application.

## Files Changed or Added

- `app/src/main/java/com/example/reginald_williams/DatabaseHelper.java`
- `app/src/main/java/com/example/reginald_williams/PasswordHasher.java`
- `app/src/main/java/com/example/reginald_williams/InventoryRepository.java`
- `app/src/main/java/com/example/reginald_williams/Item.java`
- `app/src/main/java/com/example/reginald_williams/InventoryAlgorithmEngine.java`
- `app/src/main/java/com/example/reginald_williams/InventoryAdapter.java`
- `app/src/main/java/com/example/reginald_williams/InventoryActivity.java`

## Build Note

A full Gradle build could not be completed in the sandbox because the Gradle wrapper attempts to download the Gradle distribution from `services.gradle.org`, and network access is unavailable in this environment. The files were checked through static inspection and packaged for Android Studio verification.

package com.example.reginald_williams;

/**
 * SortOptionMapper translates user-facing spinner labels into algorithm choices.
 * This keeps UI text separate from the comparison logic in InventoryAlgorithmEngine.
 */
public final class SortOptionMapper {
    public static final String PRIORITY_LABEL = "Low stock priority";
    public static final String NAME_LABEL = "Name A-Z";
    public static final String QUANTITY_LOW_LABEL = "Quantity low-high";
    public static final String QUANTITY_HIGH_LABEL = "Quantity high-low";

    private SortOptionMapper() {
        // Utility class; prevent instantiation.
    }

    public static String[] getLabels() {
        return new String[]{PRIORITY_LABEL, NAME_LABEL, QUANTITY_LOW_LABEL, QUANTITY_HIGH_LABEL};
    }

    public static InventoryAlgorithmEngine.SortMode fromLabel(String label) {
        if (NAME_LABEL.equals(label)) {
            return InventoryAlgorithmEngine.SortMode.NAME_ASCENDING;
        }
        if (QUANTITY_LOW_LABEL.equals(label)) {
            return InventoryAlgorithmEngine.SortMode.QUANTITY_ASCENDING;
        }
        if (QUANTITY_HIGH_LABEL.equals(label)) {
            return InventoryAlgorithmEngine.SortMode.QUANTITY_DESCENDING;
        }
        return InventoryAlgorithmEngine.SortMode.LOW_STOCK_PRIORITY;
    }
}

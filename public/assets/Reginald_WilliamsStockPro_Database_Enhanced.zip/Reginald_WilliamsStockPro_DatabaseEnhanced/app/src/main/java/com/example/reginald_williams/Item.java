package com.example.reginald_williams;

/**
 * Item is the standalone inventory domain model used across the UI, adapter,
 * repository, database, and algorithm layers.
 *
 * The database enhancement expands the model beyond the original name and quantity
 * fields so StockPro can support richer inventory records, item-specific reorder
 * thresholds, database-backed searching, and future synchronization work.
 */
public class Item {
    public static final String DEFAULT_CATEGORY = "General";
    public static final int DEFAULT_REORDER_THRESHOLD = 5;
    public static final int NO_OWNER_USER_ID = -1;

    private final int id;
    private final String name;
    private final int quantity;
    private final String sku;
    private final String category;
    private final int reorderThreshold;
    private final long updatedAtMillis;
    private final int ownerUserId;

    public Item(int id, String name, int quantity) {
        this(id, name, quantity, "", DEFAULT_CATEGORY, DEFAULT_REORDER_THRESHOLD, 0L, NO_OWNER_USER_ID);
    }

    public Item(
            int id,
            String name,
            int quantity,
            String sku,
            String category,
            int reorderThreshold,
            long updatedAtMillis,
            int ownerUserId
    ) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.sku = sku == null ? "" : sku;
        this.category = category == null || category.trim().isEmpty() ? DEFAULT_CATEGORY : category.trim();
        this.reorderThreshold = reorderThreshold <= 0 ? DEFAULT_REORDER_THRESHOLD : reorderThreshold;
        this.updatedAtMillis = updatedAtMillis;
        this.ownerUserId = ownerUserId;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getSku() {
        return sku;
    }

    public String getCategory() {
        return category;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public int getOwnerUserId() {
        return ownerUserId;
    }

    public int getEffectiveReorderThreshold(int fallbackThreshold) {
        return reorderThreshold > 0 ? reorderThreshold : fallbackThreshold;
    }
}

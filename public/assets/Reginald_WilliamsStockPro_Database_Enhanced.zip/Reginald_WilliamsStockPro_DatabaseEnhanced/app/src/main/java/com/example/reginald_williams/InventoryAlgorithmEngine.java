package com.example.reginald_williams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * InventoryAlgorithmEngine contains the search, filter, sort, and priority-scoring
 * logic for StockPro. Keeping these algorithms outside InventoryActivity makes
 * them easier to explain, test, and improve independently from the UI layer.
 */
public final class InventoryAlgorithmEngine {
    public enum SortMode {
        LOW_STOCK_PRIORITY,
        NAME_ASCENDING,
        QUANTITY_ASCENDING,
        QUANTITY_DESCENDING
    }

    private InventoryAlgorithmEngine() {
        // Utility class; prevent instantiation.
    }

    public static FilterResult filterAndSort(
            List<Item> sourceItems,
            String rawQuery,
            boolean lowStockOnly,
            int lowStockThreshold,
            SortMode sortMode
    ) {
        String query = normalizeQuery(rawQuery);
        List<Item> results = new ArrayList<>();

        for (Item item : sourceItems) {
            if (!matchesQuery(item, query)) {
                continue;
            }

            if (lowStockOnly && !isLowStock(item, lowStockThreshold)) {
                continue;
            }

            results.add(item);
        }

        Collections.sort(results, getComparator(sortMode, lowStockThreshold));
        return new FilterResult(results, sourceItems.size());
    }

    public static int calculatePriorityScore(Item item, int lowStockThreshold) {
        int reorderThreshold = item.getEffectiveReorderThreshold(lowStockThreshold);
        if (!isLowStock(item, lowStockThreshold)) {
            return 0;
        }

        int stockGap = reorderThreshold - item.getQuantity();
        int zeroStockBonus = item.getQuantity() == 0 ? reorderThreshold : 0;
        return stockGap + zeroStockBonus;
    }

    public static boolean isLowStock(Item item, int lowStockThreshold) {
        return item.getQuantity() < item.getEffectiveReorderThreshold(lowStockThreshold);
    }

    private static Comparator<Item> getComparator(SortMode sortMode, int lowStockThreshold) {
        switch (sortMode) {
            case NAME_ASCENDING:
                return Comparator.comparing(item -> item.getName().toLowerCase(Locale.US));
            case QUANTITY_ASCENDING:
                return Comparator.comparingInt(Item::getQuantity)
                        .thenComparing(item -> item.getName().toLowerCase(Locale.US));
            case QUANTITY_DESCENDING:
                return (first, second) -> {
                    int quantityComparison = Integer.compare(second.getQuantity(), first.getQuantity());
                    if (quantityComparison != 0) {
                        return quantityComparison;
                    }
                    return first.getName().compareToIgnoreCase(second.getName());
                };
            case LOW_STOCK_PRIORITY:
            default:
                return (first, second) -> {
                    int priorityComparison = Integer.compare(
                            calculatePriorityScore(second, lowStockThreshold),
                            calculatePriorityScore(first, lowStockThreshold)
                    );
                    if (priorityComparison != 0) {
                        return priorityComparison;
                    }
                    return first.getName().compareToIgnoreCase(second.getName());
                };
        }
    }

    private static boolean matchesQuery(Item item, String query) {
        if (query.isEmpty()) {
            return true;
        }
        return item.getName().toLowerCase(Locale.US).contains(query)
                || item.getSku().toLowerCase(Locale.US).contains(query)
                || item.getCategory().toLowerCase(Locale.US).contains(query);
    }

    private static String normalizeQuery(String rawQuery) {
        if (rawQuery == null) {
            return "";
        }
        return rawQuery.trim().toLowerCase(Locale.US);
    }

    public static class FilterResult {
        private final List<Item> items;
        private final int totalItemCount;

        public FilterResult(List<Item> items, int totalItemCount) {
            this.items = items;
            this.totalItemCount = totalItemCount;
        }

        public List<Item> getItems() {
            return items;
        }

        public int getTotalItemCount() {
            return totalItemCount;
        }

        public int getVisibleItemCount() {
            return items.size();
        }
    }
}

package com.example.reginald_williams;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashSet;
import java.util.Set;

/**
 * DatabaseHelper manages the SQLite database for the application.
 *
 * The database enhancement expands the inventory schema, preserves existing data
 * during upgrades, adds indexes and focused query methods, and stores credentials
 * as password hashes instead of clear text.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 3;

    private static final int DEFAULT_REORDER_THRESHOLD = Item.DEFAULT_REORDER_THRESHOLD;

    // Users table constants
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Items table constants
    private static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "id";
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_QTY = "quantity";
    public static final String COLUMN_ITEM_SKU = "sku";
    public static final String COLUMN_ITEM_CATEGORY = "category";
    public static final String COLUMN_ITEM_REORDER_THRESHOLD = "reorder_threshold";
    public static final String COLUMN_ITEM_UPDATED_AT = "updated_at";
    public static final String COLUMN_ITEM_OWNER_USER_ID = "owner_user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(getCreateUsersTableSql());
        db.execSQL(getCreateItemsTableSql());
        createIndexes(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Preserve existing data instead of dropping tables during schema updates.
        if (oldVersion < 3) {
            ensureBaseTables(db);
            addColumnIfMissing(db, TABLE_ITEMS, COLUMN_ITEM_SKU, "TEXT DEFAULT ''");
            addColumnIfMissing(db, TABLE_ITEMS, COLUMN_ITEM_CATEGORY, "TEXT DEFAULT 'General'");
            addColumnIfMissing(db, TABLE_ITEMS, COLUMN_ITEM_REORDER_THRESHOLD,
                    "INTEGER DEFAULT " + DEFAULT_REORDER_THRESHOLD);
            addColumnIfMissing(db, TABLE_ITEMS, COLUMN_ITEM_UPDATED_AT, "INTEGER DEFAULT 0");
            addColumnIfMissing(db, TABLE_ITEMS, COLUMN_ITEM_OWNER_USER_ID, "INTEGER DEFAULT -1");
            createIndexes(db);
        }
    }

    /* --- User Operations --- */

    /**
     * Persists a new user to the database using a password hash instead of clear text.
     * @return true if insertion was successful.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, PasswordHasher.hashPassword(password));
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Verifies user credentials against the stored password hash. If a legacy plain-text
     * password is encountered, it is migrated to a hash after a successful login.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_PASSWORD},
                COLUMN_USERNAME + "=?",
                new String[]{username}, null, null, null);

        try {
            if (!cursor.moveToFirst()) {
                return false;
            }

            int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD));
            boolean verified = PasswordHasher.verifyPassword(password, storedPassword);

            if (verified && !PasswordHasher.isHashedPassword(storedPassword)) {
                migrateLegacyPassword(db, userId, password);
            }

            return verified;
        } finally {
            cursor.close();
        }
    }

    /* --- Inventory Item Operations (CRUD and Query Methods) --- */

    /**
     * CREATE: Adds a new item with default database values for enhanced schema fields.
     */
    public long addItem(String name, int qty) {
        return addItem(name, qty, "", Item.DEFAULT_CATEGORY, DEFAULT_REORDER_THRESHOLD, Item.NO_OWNER_USER_ID);
    }

    /**
     * CREATE: Adds a complete inventory item record.
     */
    public long addItem(String name, int qty, String sku, String category, int reorderThreshold, int ownerUserId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = buildItemContentValues(name, qty, sku, category, reorderThreshold, ownerUserId);
        values.put(COLUMN_ITEM_UPDATED_AT, System.currentTimeMillis());
        return db.insert(TABLE_ITEMS, null, values);
    }

    /**
     * READ: Retrieves all items using an explicit column list instead of SELECT *.
     */
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, getItemProjection(), null, null, null, null,
                COLUMN_ITEM_NAME + " COLLATE NOCASE ASC");
    }

    /**
     * READ: Finds items by name, SKU, or category using a parameterized LIKE query.
     */
    public Cursor searchItems(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String safeQuery = query == null ? "" : query.trim();
        String likeQuery = "%" + safeQuery + "%";
        return db.query(TABLE_ITEMS, getItemProjection(),
                COLUMN_ITEM_NAME + " LIKE ? OR " + COLUMN_ITEM_SKU + " LIKE ? OR " + COLUMN_ITEM_CATEGORY + " LIKE ?",
                new String[]{likeQuery, likeQuery, likeQuery}, null, null,
                COLUMN_ITEM_NAME + " COLLATE NOCASE ASC");
    }

    /**
     * READ: Retrieves only items whose quantity is below the item-specific reorder threshold.
     */
    public Cursor getLowStockItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, getItemProjection(),
                COLUMN_ITEM_QTY + " < " + COLUMN_ITEM_REORDER_THRESHOLD,
                null, null, null,
                "(" + COLUMN_ITEM_REORDER_THRESHOLD + " - " + COLUMN_ITEM_QTY + ") DESC, "
                        + COLUMN_ITEM_NAME + " COLLATE NOCASE ASC");
    }

    /**
     * READ: Retrieves all items ordered by quantity.
     */
    public Cursor getItemsSortedByQuantity(boolean ascending) {
        SQLiteDatabase db = this.getReadableDatabase();
        String direction = ascending ? "ASC" : "DESC";
        return db.query(TABLE_ITEMS, getItemProjection(), null, null, null, null,
                COLUMN_ITEM_QTY + " " + direction + ", " + COLUMN_ITEM_NAME + " COLLATE NOCASE ASC");
    }

    /**
     * READ: Retrieves all items ordered by the highest reorder urgency first.
     */
    public Cursor getItemsSortedByPriority() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, getItemProjection(), null, null, null, null,
                "(" + COLUMN_ITEM_REORDER_THRESHOLD + " - " + COLUMN_ITEM_QTY + ") DESC, "
                        + COLUMN_ITEM_NAME + " COLLATE NOCASE ASC");
    }

    /**
     * UPDATE: Changes the quantity and records when the item was modified.
     */
    public void updateItem(int id, int qty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QTY, qty);
        values.put(COLUMN_ITEM_UPDATED_AT, System.currentTimeMillis());
        db.update(TABLE_ITEMS, values, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    /**
     * UPDATE: Changes all editable inventory details for a single item.
     */
    public void updateItemDetails(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = buildItemContentValues(
                item.getName(),
                item.getQuantity(),
                item.getSku(),
                item.getCategory(),
                item.getReorderThreshold(),
                item.getOwnerUserId()
        );
        values.put(COLUMN_ITEM_UPDATED_AT, System.currentTimeMillis());
        db.update(TABLE_ITEMS, values, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(item.getId())});
    }

    /**
     * DELETE: Removes an item from the inventory.
     */
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    private String getCreateUsersTableSql() {
        return "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COLUMN_PASSWORD + " TEXT NOT NULL)";
    }

    private String getCreateItemsTableSql() {
        return "CREATE TABLE IF NOT EXISTS " + TABLE_ITEMS + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                COLUMN_ITEM_SKU + " TEXT DEFAULT '', " +
                COLUMN_ITEM_CATEGORY + " TEXT DEFAULT 'General', " +
                COLUMN_ITEM_REORDER_THRESHOLD + " INTEGER NOT NULL DEFAULT " + DEFAULT_REORDER_THRESHOLD + ", " +
                COLUMN_ITEM_UPDATED_AT + " INTEGER NOT NULL DEFAULT 0, " +
                COLUMN_ITEM_OWNER_USER_ID + " INTEGER DEFAULT -1)";
    }

    private ContentValues buildItemContentValues(String name, int qty, String sku, String category, int reorderThreshold, int ownerUserId) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QTY, qty);
        values.put(COLUMN_ITEM_SKU, sku == null ? "" : sku.trim());
        values.put(COLUMN_ITEM_CATEGORY, category == null || category.trim().isEmpty()
                ? Item.DEFAULT_CATEGORY : category.trim());
        values.put(COLUMN_ITEM_REORDER_THRESHOLD, reorderThreshold <= 0 ? DEFAULT_REORDER_THRESHOLD : reorderThreshold);
        values.put(COLUMN_ITEM_OWNER_USER_ID, ownerUserId);
        return values;
    }

    private String[] getItemProjection() {
        return new String[]{
                COLUMN_ITEM_ID,
                COLUMN_ITEM_NAME,
                COLUMN_ITEM_QTY,
                COLUMN_ITEM_SKU,
                COLUMN_ITEM_CATEGORY,
                COLUMN_ITEM_REORDER_THRESHOLD,
                COLUMN_ITEM_UPDATED_AT,
                COLUMN_ITEM_OWNER_USER_ID
        };
    }

    private void ensureBaseTables(SQLiteDatabase db) {
        db.execSQL(getCreateUsersTableSql());
        db.execSQL(getCreateItemsTableSql());
    }

    private void addColumnIfMissing(SQLiteDatabase db, String tableName, String columnName, String columnDefinition) {
        if (tableHasColumn(db, tableName, columnName)) {
            return;
        }
        db.execSQL("ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnDefinition);
    }

    private boolean tableHasColumn(SQLiteDatabase db, String tableName, String columnName) {
        Set<String> existingColumns = new HashSet<>();
        Cursor cursor = db.rawQuery("PRAGMA table_info(" + tableName + ")", null);
        try {
            int columnNameIndex = cursor.getColumnIndexOrThrow("name");
            while (cursor.moveToNext()) {
                existingColumns.add(cursor.getString(columnNameIndex));
            }
        } finally {
            cursor.close();
        }
        return existingColumns.contains(columnName);
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_name ON " + TABLE_ITEMS + "(" + COLUMN_ITEM_NAME + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_sku ON " + TABLE_ITEMS + "(" + COLUMN_ITEM_SKU + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_category ON " + TABLE_ITEMS + "(" + COLUMN_ITEM_CATEGORY + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_low_stock ON " + TABLE_ITEMS + "("
                + COLUMN_ITEM_QTY + ", " + COLUMN_ITEM_REORDER_THRESHOLD + ")");
    }

    private void migrateLegacyPassword(SQLiteDatabase db, int userId, String plainTextPassword) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, PasswordHasher.hashPassword(plainTextPassword));
        db.update(TABLE_USERS, values, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});
    }
}

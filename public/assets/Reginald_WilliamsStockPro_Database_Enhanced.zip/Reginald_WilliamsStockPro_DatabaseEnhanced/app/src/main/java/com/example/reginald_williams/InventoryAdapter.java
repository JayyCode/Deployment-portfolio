package com.example.reginald_williams;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * InventoryAdapter binds inventory data to the RecyclerView grid display.
 * It depends on the standalone Item model and displays algorithm-derived
 * low-stock priority information so the list supports faster decisions.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private final List<Item> itemList;
    private final int lowStockThreshold;
    private final OnItemInteractionListener interactionListener;

    /**
     * Interface to handle UI events within the data grid.
     */
    public interface OnItemInteractionListener {
        void onDeleteClick(int id);
        void onUpdateClick(Item item);
    }

    public InventoryAdapter(List<Item> itemList, int lowStockThreshold, OnItemInteractionListener listener) {
        this.itemList = itemList;
        this.lowStockThreshold = lowStockThreshold;
        this.interactionListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = itemList.get(position);
        boolean isLowStock = InventoryAlgorithmEngine.isLowStock(item, lowStockThreshold);
        int priorityScore = InventoryAlgorithmEngine.calculatePriorityScore(item, lowStockThreshold);

        holder.nameText.setText(item.getName());
        holder.qtyText.setText("Stock: " + item.getQuantity() + " | Reorder: " + item.getReorderThreshold());
        if (isLowStock) {
            holder.statusText.setText("Low stock | Priority " + priorityScore + " | " + item.getCategory());
            holder.statusText.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.warning_red));
        } else {
            holder.statusText.setText("Stock level OK | " + item.getCategory());
            holder.statusText.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.accent_blue));
        }

        holder.deleteBtn.setOnClickListener(v -> interactionListener.onDeleteClick(item.getId()));
        holder.itemView.setOnClickListener(v -> interactionListener.onUpdateClick(item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    /**
     * ViewHolder pattern for efficient UI element reuse.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView qtyText;
        final TextView statusText;
        final Button deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemName);
            qtyText = itemView.findViewById(R.id.itemQty);
            statusText = itemView.findViewById(R.id.itemStatus);
            deleteBtn = itemView.findViewById(R.id.deleteButton);
        }
    }
}

package com.example.reginald_williams;

import android.content.Context;

/**
 * AuthRepository separates authentication decisions from LoginActivity.
 * LoginActivity can now focus on UI behavior while this repository handles
 * interaction with persistent user storage.
 */
public class AuthRepository {
    private final DatabaseHelper databaseHelper;

    public AuthRepository(Context context) {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public boolean createAccount(String username, String password) {
        return databaseHelper.addUser(username, password);
    }

    public boolean login(String username, String password) {
        return databaseHelper.checkUser(username, password);
    }
}

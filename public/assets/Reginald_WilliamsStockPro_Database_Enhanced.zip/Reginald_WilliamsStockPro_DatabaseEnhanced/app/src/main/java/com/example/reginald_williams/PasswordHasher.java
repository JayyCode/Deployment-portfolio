package com.example.reginald_williams;

import android.util.Base64;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * PasswordHasher keeps credential handling out of the Activity layer and avoids
 * storing clear-text passwords in SQLite. The stored value includes the algorithm,
 * iteration count, salt, and derived key so credentials can be verified later.
 */
public final class PasswordHasher {
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 120000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_LENGTH_BYTES = 16;
    private static final String HASH_PREFIX = "PBKDF2";
    private static final String DELIMITER = "$";

    private PasswordHasher() {
        // Utility class; prevent instantiation.
    }

    public static String hashPassword(String password) {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = deriveKey(password, salt, ITERATIONS);
        return HASH_PREFIX + DELIMITER
                + ITERATIONS + DELIMITER
                + encode(salt) + DELIMITER
                + encode(hash);
    }

    public static boolean verifyPassword(String password, String storedPassword) {
        if (storedPassword == null || password == null) {
            return false;
        }

        if (!isHashedPassword(storedPassword)) {
            return password.equals(storedPassword);
        }

        String[] parts = storedPassword.split("\\$", -1);
        if (parts.length != 4) {
            return false;
        }

        int iterations;
        try {
            iterations = Integer.parseInt(parts[1]);
        } catch (NumberFormatException exception) {
            return false;
        }

        byte[] salt = decode(parts[2]);
        byte[] expectedHash = decode(parts[3]);
        byte[] actualHash = deriveKey(password, salt, iterations);
        return constantTimeEquals(expectedHash, actualHash);
    }

    public static boolean isHashedPassword(String storedPassword) {
        return storedPassword != null && storedPassword.startsWith(HASH_PREFIX + DELIMITER);
    }

    private static byte[] deriveKey(String password, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, KEY_LENGTH_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            return factory.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException exception) {
            throw new IllegalStateException("Unable to hash password", exception);
        }
    }

    private static boolean constantTimeEquals(byte[] expected, byte[] actual) {
        if (expected == null || actual == null || expected.length != actual.length) {
            return false;
        }

        int result = 0;
        for (int index = 0; index < expected.length; index++) {
            result |= expected[index] ^ actual[index];
        }
        return result == 0;
    }

    private static String encode(byte[] data) {
        return Base64.encodeToString(data, Base64.NO_WRAP);
    }

    private static byte[] decode(String value) {
        return Base64.decode(value, Base64.NO_WRAP);
    }
}

package com.example.reginald_williams;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity provides the entry point for users to authenticate or create a new account.
 * It now delegates authentication work to AuthRepository and uses InputValidator for reusable
 * input checks, keeping the activity focused on screen behavior.
 */
public class LoginActivity extends AppCompatActivity {
    private EditText usernameEdit, passwordEdit;
    private AuthRepository authRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authRepository = new AuthRepository(this);

        usernameEdit = findViewById(R.id.username);
        passwordEdit = findViewById(R.id.password);
        Button loginBtn = findViewById(R.id.loginButton);
        Button createAccountBtn = findViewById(R.id.createAccountButton);

        loginBtn.setOnClickListener(v -> handleLogin());
        createAccountBtn.setOnClickListener(v -> handleCreateAccount());
    }

    /**
     * Handles login UI events while delegating validation and authentication checks.
     */
    private void handleLogin() {
        String user = InputValidator.normalizeText(usernameEdit.getText().toString());
        String pass = InputValidator.normalizeText(passwordEdit.getText().toString());
        String credentialError = InputValidator.getCredentialError(user, pass);

        if (credentialError != null) {
            showMessage(credentialError);
            return;
        }

        if (authRepository.login(user, pass)) {
            startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            finish();
        } else {
            showMessage("Authentication failed. Please try again.");
        }
    }

    /**
     * Handles account creation UI events while delegating persistence to AuthRepository.
     */
    private void handleCreateAccount() {
        String user = InputValidator.normalizeText(usernameEdit.getText().toString());
        String pass = InputValidator.normalizeText(passwordEdit.getText().toString());
        String credentialError = InputValidator.getCredentialError(user, pass);

        if (credentialError != null) {
            showMessage(credentialError);
            return;
        }

        if (authRepository.createAccount(user, pass)) {
            showMessage("Account created successfully! You can now log in.");
        } else {
            showMessage("Username already exists. Choose a different one.");
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

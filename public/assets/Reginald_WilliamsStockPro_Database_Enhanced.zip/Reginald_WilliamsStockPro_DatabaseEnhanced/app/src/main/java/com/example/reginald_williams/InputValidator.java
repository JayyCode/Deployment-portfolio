package com.example.reginald_williams;

/**
 * InputValidator centralizes reusable input checks so activities do not each
 * duplicate validation logic. This supports maintainability and reduces crashes
 * caused by invalid user input.
 */
public final class InputValidator {
    private InputValidator() {
        // Utility class; prevent instantiation.
    }

    public static String normalizeText(String value) {
        return value == null ? "" : value.trim();
    }

    public static boolean isBlank(String value) {
        return normalizeText(value).isEmpty();
    }

    public static String getCredentialError(String username, String password) {
        if (isBlank(username) || isBlank(password)) {
            return "Please enter both username and password";
        }
        return null;
    }

    public static String getItemNameError(String itemName) {
        if (isBlank(itemName)) {
            return "Please enter an item name";
        }
        return null;
    }

    public static QuantityValidationResult validateQuantity(String rawQuantity) {
        String cleanedQuantity = normalizeText(rawQuantity);

        if (cleanedQuantity.isEmpty()) {
            return QuantityValidationResult.invalid("Please enter a quantity");
        }

        try {
            int quantity = Integer.parseInt(cleanedQuantity);
            if (quantity < 0) {
                return QuantityValidationResult.invalid("Quantity cannot be negative");
            }
            return QuantityValidationResult.valid(quantity);
        } catch (NumberFormatException exception) {
            return QuantityValidationResult.invalid("Quantity must be a whole number");
        }
    }

    public static class QuantityValidationResult {
        private final boolean valid;
        private final int quantity;
        private final String errorMessage;

        private QuantityValidationResult(boolean valid, int quantity, String errorMessage) {
            this.valid = valid;
            this.quantity = quantity;
            this.errorMessage = errorMessage;
        }

        public static QuantityValidationResult valid(int quantity) {
            return new QuantityValidationResult(true, quantity, null);
        }

        public static QuantityValidationResult invalid(String errorMessage) {
            return new QuantityValidationResult(false, 0, errorMessage);
        }

        public boolean isValid() {
            return valid;
        }

        public int getQuantity() {
            return quantity;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}

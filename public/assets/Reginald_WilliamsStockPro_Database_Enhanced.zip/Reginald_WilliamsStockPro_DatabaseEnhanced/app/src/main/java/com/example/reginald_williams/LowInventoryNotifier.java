package com.example.reginald_williams;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

/**
 * LowInventoryNotifier separates notification behavior from InventoryActivity.
 * The activity decides when to notify; this class handles whether SMS is allowed
 * and how the notification is sent.
 */
public class LowInventoryNotifier {
    private static final String DEMO_PHONE_NUMBER = "5551234";

    private final Context context;

    public LowInventoryNotifier(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean canSendSms() {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public void sendLowInventoryAlert(String itemName, int quantity) {
        if (!canSendSms()) {
            return;
        }

        SmsManager smsManager = context.getSystemService(SmsManager.class);
        String message = "Alert: Low inventory for " + itemName + ". Current stock: " + quantity;
        smsManager.sendTextMessage(DEMO_PHONE_NUMBER, null, message, null, null);
    }
}

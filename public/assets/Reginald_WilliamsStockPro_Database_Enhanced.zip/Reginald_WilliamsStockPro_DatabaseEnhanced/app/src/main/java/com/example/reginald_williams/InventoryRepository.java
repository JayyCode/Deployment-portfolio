package com.example.reginald_williams;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryRepository provides a clean boundary between InventoryActivity and
 * DatabaseHelper. UI classes call repository methods instead of working with
 * Cursor objects or raw database operations directly.
 *
 * The database enhancement adds focused read methods so callers can use explicit
 * database queries for searching, low-stock retrieval, quantity sorting, and
 * priority ordering when dataset size or use case requires database-level work.
 */
public class InventoryRepository {
    private final DatabaseHelper databaseHelper;

    public InventoryRepository(Context context) {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public long addItem(String name, int quantity) {
        return databaseHelper.addItem(name, quantity);
    }

    public long addItem(String name, int quantity, String sku, String category, int reorderThreshold, int ownerUserId) {
        return databaseHelper.addItem(name, quantity, sku, category, reorderThreshold, ownerUserId);
    }

    public void updateQuantity(int itemId, int quantity) {
        databaseHelper.updateItem(itemId, quantity);
    }

    public void updateItemDetails(Item item) {
        databaseHelper.updateItemDetails(item);
    }

    public void deleteItem(int itemId) {
        databaseHelper.deleteItem(itemId);
    }

    public List<Item> getAllItems() {
        return readItems(databaseHelper.getAllItems());
    }

    public List<Item> searchItems(String query) {
        return readItems(databaseHelper.searchItems(query));
    }

    public List<Item> getLowStockItems() {
        return readItems(databaseHelper.getLowStockItems());
    }

    public List<Item> getItemsSortedByQuantity(boolean ascending) {
        return readItems(databaseHelper.getItemsSortedByQuantity(ascending));
    }

    public List<Item> getItemsSortedByPriority() {
        return readItems(databaseHelper.getItemsSortedByPriority());
    }

    private List<Item> readItems(Cursor cursor) {
        List<Item> items = new ArrayList<>();

        if (cursor == null) {
            return items;
        }

        try {
            if (cursor.moveToFirst()) {
                do {
                    items.add(cursorToItem(cursor));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }

        return items;
    }

    private Item cursorToItem(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
        String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
        int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QTY));
        String sku = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_SKU));
        String category = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_CATEGORY));
        int reorderThreshold = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_REORDER_THRESHOLD));
        long updatedAt = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_UPDATED_AT));
        int ownerUserId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_OWNER_USER_ID));
        return new Item(id, name, quantity, sku, category, reorderThreshold, updatedAt, ownerUserId);
    }
}

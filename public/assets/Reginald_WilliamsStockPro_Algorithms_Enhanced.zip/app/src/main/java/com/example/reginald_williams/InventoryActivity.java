package com.example.reginald_williams;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryActivity manages the inventory screen and delegates persistence,
 * validation, notification, and algorithmic list operations to focused helper
 * classes. This keeps the activity responsible for UI behavior instead of
 * combining every application responsibility in one file.
 */
public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private static final int LOW_STOCK_THRESHOLD = 5;

    private InventoryRepository inventoryRepository;
    private LowInventoryNotifier lowInventoryNotifier;
    private InventoryAdapter adapter;
    private List<Item> itemList;
    private List<Item> allItems;
    private EditText nameInput, qtyInput, searchInput;
    private CheckBox lowStockOnlyCheckBox;
    private Spinner sortSpinner;
    private TextView inventorySummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryRepository = new InventoryRepository(this);
        lowInventoryNotifier = new LowInventoryNotifier(this);
        itemList = new ArrayList<>();
        allItems = new ArrayList<>();

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new InventoryAdapter(itemList, LOW_STOCK_THRESHOLD, new InventoryAdapter.OnItemInteractionListener() {
            @Override
            public void onDeleteClick(int id) {
                deleteItem(id);
            }

            @Override
            public void onUpdateClick(Item item) {
                showUpdateDialog(item);
            }
        });
        recyclerView.setAdapter(adapter);

        nameInput = findViewById(R.id.newItemName);
        qtyInput = findViewById(R.id.newItemQty);
        searchInput = findViewById(R.id.searchInventory);
        lowStockOnlyCheckBox = findViewById(R.id.lowStockOnlyCheckBox);
        sortSpinner = findViewById(R.id.sortSpinner);
        inventorySummary = findViewById(R.id.inventorySummary);
        View addBtn = findViewById(R.id.addButton);
        View smsBtn = findViewById(R.id.smsPermissionButton);

        addBtn.setOnClickListener(v -> addItemFromInput());
        smsBtn.setOnClickListener(v -> requestSmsPermissionIfNeeded());
        setupAlgorithmControls();

        refreshList();
    }

    /**
     * Connects search, filter, and sort controls to the inventory algorithm engine.
     */
    private void setupAlgorithmControls() {
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                SortOptionMapper.getLabels()
        );
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(sortAdapter);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence value, int start, int count, int after) {
                // No action needed before the search text changes.
            }

            @Override
            public void onTextChanged(CharSequence value, int start, int before, int count) {
                applyInventoryAlgorithms();
            }

            @Override
            public void afterTextChanged(Editable value) {
                // Filtering happens in onTextChanged to keep results responsive.
            }
        });

        lowStockOnlyCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> applyInventoryAlgorithms());

        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyInventoryAlgorithms();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                applyInventoryAlgorithms();
            }
        });
    }

    /**
     * Validates user-entered item data before sending the request to the repository layer.
     */
    private void addItemFromInput() {
        String name = InputValidator.normalizeText(nameInput.getText().toString());
        String nameError = InputValidator.getItemNameError(name);
        InputValidator.QuantityValidationResult quantityResult =
                InputValidator.validateQuantity(qtyInput.getText().toString());

        if (nameError != null) {
            showMessage(nameError);
            return;
        }

        if (!quantityResult.isValid()) {
            showMessage(quantityResult.getErrorMessage());
            return;
        }

        int quantity = quantityResult.getQuantity();
        inventoryRepository.addItem(name, quantity);
        clearItemInputs();
        refreshList();
        notifyIfLowInventory(name, quantity);
    }

    /**
     * Deletes an inventory item and refreshes the UI after persistence completes.
     */
    private void deleteItem(int id) {
        inventoryRepository.deleteItem(id);
        refreshList();
        showMessage("Item deleted");
    }

    /**
     * Shows a dialog to update the quantity of a selected item.
     * @param item The item to be updated.
     */
    private void showUpdateDialog(Item item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_update_item, null);
        builder.setView(dialogView);

        EditText editQty = dialogView.findViewById(R.id.editItemQty);
        editQty.setText(String.valueOf(item.getQuantity()));

        builder.setTitle("Update " + item.getName())
               .setPositiveButton("Update", null)
               .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(dialogInterface -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> handleUpdateQuantity(dialog, item, editQty)));
        dialog.show();
    }

    /**
     * Validates updated quantity values before changing persistent inventory data.
     */
    private void handleUpdateQuantity(AlertDialog dialog, Item item, EditText editQty) {
        InputValidator.QuantityValidationResult quantityResult =
                InputValidator.validateQuantity(editQty.getText().toString());

        if (!quantityResult.isValid()) {
            showMessage(quantityResult.getErrorMessage());
            return;
        }

        int newQuantity = quantityResult.getQuantity();
        inventoryRepository.updateQuantity(item.getId(), newQuantity);
        refreshList();
        notifyIfLowInventory(item.getName(), newQuantity);
        dialog.dismiss();
    }

    /**
     * Synchronizes the complete inventory dataset with the repository layer.
     */
    private void refreshList() {
        allItems.clear();
        allItems.addAll(inventoryRepository.getAllItems());
        applyInventoryAlgorithms();
    }

    /**
     * Applies search, low-stock filtering, priority scoring, and sorting to the UI list.
     */
    private void applyInventoryAlgorithms() {
        if (adapter == null || searchInput == null || lowStockOnlyCheckBox == null || sortSpinner == null) {
            return;
        }

        String selectedLabel = String.valueOf(sortSpinner.getSelectedItem());
        InventoryAlgorithmEngine.FilterResult result = InventoryAlgorithmEngine.filterAndSort(
                allItems,
                searchInput.getText().toString(),
                lowStockOnlyCheckBox.isChecked(),
                LOW_STOCK_THRESHOLD,
                SortOptionMapper.fromLabel(selectedLabel)
        );

        itemList.clear();
        itemList.addAll(result.getItems());
        adapter.notifyDataSetChanged();
        updateInventorySummary(result);
    }

    private void updateInventorySummary(InventoryAlgorithmEngine.FilterResult result) {
        inventorySummary.setText("Showing " + result.getVisibleItemCount()
                + " of " + result.getTotalItemCount() + " items");
    }

    /**
     * Sends a low-stock notification when inventory drops below the defined threshold.
     */
    private void notifyIfLowInventory(String name, int quantity) {
        if (quantity >= LOW_STOCK_THRESHOLD) {
            return;
        }

        try {
            lowInventoryNotifier.sendLowInventoryAlert(name, quantity);
            if (lowInventoryNotifier.canSendSms()) {
                showMessage("Notification Sent: Low Stock");
            }
        } catch (Exception exception) {
            showMessage("SMS failure: " + exception.getMessage());
        }
    }

    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            showMessage("SMS Permission already granted");
        }
    }

    private void clearItemInputs() {
        nameInput.setText("");
        qtyInput.setText("");
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showMessage("SMS functionality enabled");
            } else {
                showMessage("SMS notifications will be disabled");
            }
        }
    }
}

# CS 499 Milestone Three: Algorithms and Data Structures Enhancement

## Artifact
StockPro is the CS 360 Android mobile inventory application enhanced in the previous milestone for software design and engineering.

## Enhancement Scope
This milestone adds the planned algorithms and data structures enhancement while preserving the software-engineering refactor already completed.

## Implemented Changes
- Added `InventoryAlgorithmEngine.java` to centralize search, low-stock filtering, sorting, and priority scoring.
- Added `SortOptionMapper.java` to translate UI spinner labels into algorithm sort modes.
- Updated `InventoryActivity.java` to maintain both a complete `allItems` dataset and a visible `itemList` dataset.
- Added responsive search using `TextWatcher`.
- Added a low-stock-only filter using `CheckBox`.
- Added a sort mode selector using `Spinner`.
- Added an inventory summary that reports visible item count versus total item count.
- Updated `InventoryAdapter.java` to display algorithm-derived low-stock status and priority score for each row.
- Updated `activity_inventory.xml` and `item_row.xml` to expose the new algorithmic controls and output.

## Algorithmic Value
The original app displayed inventory in the order returned by SQLite and relied on a single hard-coded low-stock threshold. The enhanced version applies a data-processing pipeline:

1. Load inventory records into an in-memory list.
2. Normalize the search query.
3. Filter records by item name if search text is present.
4. Optionally filter to low-stock records only.
5. Calculate a priority score for low-stock items.
6. Sort records by priority, name, quantity ascending, or quantity descending.
7. Update the RecyclerView with the resulting list.

## Complexity and Trade-Offs
- Search and low-stock filtering are O(n) because each item must be evaluated.
- Sorting is O(n log n), which is acceptable for a mobile inventory list.
- The app keeps a full list and a visible list, which uses more memory than a single list but gives the UI responsive search and filter behavior.
- If the dataset grew significantly, some search and sorting behavior could be moved into indexed SQLite queries in the database milestone.

package com.example.reginald_williams;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryActivity manages the display, addition, deletion, and updating of inventory items.
 * It also handles SMS permissions and notifications for low inventory levels.
 */
public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private DatabaseHelper dbHelper;
    private InventoryAdapter adapter;
    private List<Item> itemList;
    private EditText nameInput, qtyInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize database helper and data list
        dbHelper = new DatabaseHelper(this);
        itemList = new ArrayList<>();
        
        // Configure RecyclerView for the data grid
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Define adapter with callbacks for delete and update actions
        adapter = new InventoryAdapter(itemList, new InventoryAdapter.OnItemInteractionListener() {
            @Override
            public void onDeleteClick(int id) {
                dbHelper.deleteItem(id);
                refreshList();
                Toast.makeText(InventoryActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onUpdateClick(Item item) {
                showUpdateDialog(item);
            }
        });
        recyclerView.setAdapter(adapter);

        // Initialize UI components for adding new data
        nameInput = findViewById(R.id.newItemName);
        qtyInput = findViewById(R.id.newItemQty);
        View addBtn = findViewById(R.id.addButton);
        View smsBtn = findViewById(R.id.smsPermissionButton);

        // Handle Add Item action
        addBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String qtyStr = qtyInput.getText().toString().trim();
            
            if (!name.isEmpty() && !qtyStr.isEmpty()) {
                int qty = Integer.parseInt(qtyStr);
                dbHelper.addItem(name, qty);
                nameInput.setText("");
                qtyInput.setText("");
                refreshList();
                checkLowInventory(name, qty); // Check if notification is needed
            } else {
                Toast.makeText(this, "Please enter name and quantity", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle SMS Permission request
        smsBtn.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            }
        });

        // Load initial data from database
        refreshList();
    }

    /**
     * Shows a dialog to update the quantity of a selected item.
     * @param item The item to be updated.
     */
    private void showUpdateDialog(Item item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_update_item, null);
        builder.setView(dialogView);

        EditText editQty = dialogView.findViewById(R.id.editItemQty);
        editQty.setText(String.valueOf(item.qty));

        builder.setTitle("Update " + item.name)
               .setPositiveButton("Update", (dialog, id) -> {
                   String newQtyStr = editQty.getText().toString().trim();
                   if (!newQtyStr.isEmpty()) {
                       int newQty = Integer.parseInt(newQtyStr);
                       dbHelper.updateItem(item.id, newQty);
                       refreshList();
                       checkLowInventory(item.name, newQty);
                   }
               })
               .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());
        
        builder.create().show();
    }

    /**
     * Synchronizes the in-memory list with the persistent database.
     */
    private void refreshList() {
        itemList.clear();
        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int qty = cursor.getInt(2);
                itemList.add(new Item(id, name, qty));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    /**
     * Triggers an SMS notification if inventory level falls below the threshold.
     */
    private void checkLowInventory(String name, int qty) {
        if (qty < 5) {
            sendSmsNotification("Alert: Low inventory for " + name + ". Current stock: " + qty);
        }
    }

    /**
     * Sends an SMS message if permission is granted.
     * @param message The content of the notification.
     */
    private void sendSmsNotification(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = this.getSystemService(SmsManager.class);
                // Dummy phone number for demonstration purposes
                smsManager.sendTextMessage("5551234", null, message, null, null);
                Toast.makeText(this, "Notification Sent: Low Stock", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failure: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        // If permission is denied, the app continues to function without notifications.
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS functionality enabled", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS notifications will be disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Data model for Inventory Items.
     */
    public static class Item {
        public int id;
        public String name;
        public int qty;
        
        public Item(int id, String name, int qty) { 
            this.id = id; 
            this.name = name; 
            this.qty = qty; 
        }
    }
}

package com.example.reginald_williams;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity provides the entry point for users to authenticate or create a new account.
 * It manages interaction between the UI and the SQLite database via DatabaseHelper.
 */
public class LoginActivity extends AppCompatActivity {
    private EditText usernameEdit, passwordEdit;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper for persistence
        dbHelper = new DatabaseHelper(this);
        
        // Bind UI components
        usernameEdit = findViewById(R.id.username);
        passwordEdit = findViewById(R.id.password);
        Button loginBtn = findViewById(R.id.loginButton);
        Button createAccountBtn = findViewById(R.id.createAccountButton);

        // Define Login logic
        loginBtn.setOnClickListener(v -> {
            String user = usernameEdit.getText().toString().trim();
            String pass = passwordEdit.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate credentials against persistent database
            if (dbHelper.checkUser(user, pass)) {
                // On success, navigate to the inventory grid screen
                startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Authentication failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });

        // Define Account Creation logic
        createAccountBtn.setOnClickListener(v -> {
            String user = usernameEdit.getText().toString().trim();
            String pass = passwordEdit.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Fields cannot be empty for new account creation", Toast.LENGTH_SHORT).show();
                return;
            }

            // Attempt to add new user to the database shell
            if (dbHelper.addUser(user, pass)) {
                Toast.makeText(this, "Account created successfully! You can now log in.", Toast.LENGTH_SHORT).show();
            } else {
                // Logic handles duplicate usernames via SQLite UNIQUE constraint
                Toast.makeText(this, "Username already exists. Choose a different one.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

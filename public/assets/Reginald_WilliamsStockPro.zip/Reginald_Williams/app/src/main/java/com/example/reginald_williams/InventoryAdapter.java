package com.example.reginald_williams;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * InventoryAdapter binds the inventory data to the RecyclerView grid display.
 * It manages item interactions such as clicking to update or deleting an item.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private final List<InventoryActivity.Item> itemList;
    private final OnItemInteractionListener interactionListener;

    /**
     * Interface to handle UI events within the data grid.
     */
    public interface OnItemInteractionListener {
        void onDeleteClick(int id);
        void onUpdateClick(InventoryActivity.Item item);
    }

    public InventoryAdapter(List<InventoryActivity.Item> itemList, OnItemInteractionListener listener) {
        this.itemList = itemList;
        this.interactionListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the row layout for individual grid items
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryActivity.Item item = itemList.get(position);
        
        // Map data to UI elements
        holder.nameText.setText(item.name);
        holder.qtyText.setText("Stock: " + item.qty);

        // Set up interactions for Read, Update, and Delete actions
        holder.deleteBtn.setOnClickListener(v -> interactionListener.onDeleteClick(item.id));
        
        // Clicking the item row triggers the update workflow
        holder.itemView.setOnClickListener(v -> interactionListener.onUpdateClick(item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    /**
     * ViewHolder pattern for efficient UI element reuse.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView qtyText;
        final Button deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemName);
            qtyText = itemView.findViewById(R.id.itemQty);
            deleteBtn = itemView.findViewById(R.id.deleteButton);
        }
    }
}
